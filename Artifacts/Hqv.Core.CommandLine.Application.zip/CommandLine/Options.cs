﻿namespace $safeprojectname$
{
    /// <summary>
    /// Used by command line library (https://github.com/gsscoder/commandline).
    /// 
    /// todo: add options
    /// </summary>
    internal class Options
    {
    }
}