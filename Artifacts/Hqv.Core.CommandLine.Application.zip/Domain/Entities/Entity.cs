﻿namespace $safeprojectname$.Entities
{
    /// <summary>
    /// todo: Add entities 
    /// </summary>
    public class Entity
    {
    }
}